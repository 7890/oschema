package xsdvi.svg;

import xsdvi.utils.WidthCalculator;

/**
 * @author V�clav Slav�t�nsk�
 *
 */
public class SymbolSchema extends AbstractSymbol {
	
	/**
	 * 
	 */
	public SymbolSchema() {
		super();
	}
	
	/* (non-Javadoc)
	 * @see xsdvi.svg.AbstractSymbol#draw()
	 */
	@Override
	public void draw() {
		drawGStart();
		print("<rect class='boxschema' x='0' y='12' width='"+width+"' height='"+height+"'/>");
		print("<text x='5' y='27'><tspan class='big'>/ </tspan>schema</text>");
		drawUse();
		drawGEnd();
	}
	
	/* (non-Javadoc)
	 * @see xsdvi.svg.AbstractSymbol#getWidth()
	 */
	@Override
	public int getWidth() {
		WidthCalculator calc = new WidthCalculator(MIN_WIDTH);
		calc.newWidth(15, 8);
		return calc.getWidth();
	}
	
	/* (non-Javadoc)
	 * @see xsdvi.svg.AbstractSymbol#getHeight()
	 */
	@Override
	public int getHeight() {
		return MIN_HEIGHT;
	}
}